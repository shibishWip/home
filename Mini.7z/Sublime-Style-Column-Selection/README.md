# Sublime Style Column Selection

Enable Sublime style 'Column Selection'.

Also similar to Texmate's 'Multiple Carets', or BBEdit's 'Block Select'

![](https://raw.github.com/bigfive/atom-sublime-select/master/screenshot.png)
